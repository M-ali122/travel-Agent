package com.example.travelagentapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
