import 'package:flutter/material.dart';

class RecommanationScreen extends StatelessWidget {
  static const String route = "RecommanationScreen";
  const RecommanationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: ListView(
      children: [],
    ));
  }
}
